#ifndef COMPDATETIME_H
#define COMPDATETIME_H
#include <queue>
#include <string>
#include <cstdlib>

using namespace std;

class CompDateTime
{
public:
    CompDateTime();
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int ms;
    void setUDPTimes(string message);
    string toUdpString();
    int compVal(CompDateTime d2);
    void addSec(int ms);
    int arr[12] = {31,28,31,30,31,30,31,31,30,31,30,31};


    /**
     * @brief compare
     * This function is a way to compare two CompDateTimes (for use in something like a priority queue)
     * @param d1: The first object to compare
     * @param d2: The second object to compare
     * @return A way to show if d1 is greater than d2 (negative means d1 is greater, zero means they are equal, positive means d2 is greater
     */
    int compare(CompDateTime *d1, CompDateTime d2){
        int deltaYear = d2.year - d1->year;
        int deltaMonth = d2.month - d1->month;
        int deltaDay = d2.day - d1->day;
        int deltaHour = d2.hour - d1->hour;
        int deltaMinute = d2.minute - d1->minute;
        int deltaSec = d2.second - d1->second;
        int deltaMs = d2.ms - d1->ms;
        if(deltaYear < 0){
            return -1000000;
        }
        else if(deltaYear > 0){
            return 1000000;
        }
        else{
            if(deltaMonth < 0){
                return -1000000;
            }
            else if(deltaMonth > 0){
                return 1000000;
            }
            else{
                if(deltaDay < 0){
                    return -1000000;
                }
                else if(deltaDay > 0){
                    return 1000000;
                }
                else{
                    int timeDelta = deltaHour;
                    timeDelta *= 60;
                    timeDelta += deltaMinute;
                    timeDelta *= 60;
                    timeDelta += deltaSec;
                    timeDelta *= 1000;
                    timeDelta += deltaMs;
                    if(timeDelta == 0){
                        return 0;
                    }
                    else{
                        return timeDelta;
                    }
                }
            }
        }
    }
};

#endif // COMPDATETIME_H
