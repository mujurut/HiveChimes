#include "compdatetime.h"

CompDateTime::CompDateTime()
{

}

/**
 * @brief CompDateTime::setUDPTimes
 * This function takes the time string from a UDP message and uses the specific
 * char locations in it to get the parts of the date and time
 * @param message: The time string to be used
 */
void CompDateTime::setUDPTimes(string message){
    day = stoi(message.substr(1,2));
    month = stoi(message.substr(4,2));
    year = 2000 + stoi(message.substr(7,2));
    if(year >= 4000){year-=2000;}
    hour = stoi(message.substr(10,2));
    minute = stoi(message.substr(13,2));
    second = stoi(message.substr(16,2));
    ms = stoi(message.substr(18,3));
}


/**
 * @brief CompDateTime::toUdpString
 * This function can be used in creating UDP messages from a CompDateTime object as this converts the specific date
 * and time into the format of a date time string of a UDP message
 * @return
 */
string CompDateTime::toUdpString(){
    string returnString = "D";
    if(day < 10){
        returnString += "0";
    }
    returnString += to_string(day);
    returnString += ".";
    if(month < 10){
        returnString += "0";
    }
    returnString += to_string(month);
    returnString += ".";
    if(year%100 < 10){
        returnString += "0";
    }
    returnString += to_string(year);
    returnString += "T";
    if(hour < 10){
        returnString += "0";
    }
    returnString += to_string(hour);
    returnString += ".";
    if(minute < 10){
        returnString += "0";
    }
    returnString += to_string(minute);
    returnString += ".";
    if(second < 10){
        returnString += "0";
    }
    returnString += to_string(second);
    if(ms < 100){
        returnString += "0";
    }
    if(ms < 10){
        returnString += "0";
    }
    returnString += to_string(ms);
    return returnString;
}

int CompDateTime::compVal(CompDateTime d2){
    return compare(this,d2);
}

void CompDateTime::addSec(int milli){
    int addS = 0;
    if(milli > 60000){
        return;
    }
    else if(milli >= 1000){
        addS = milli/1000;
        second += addS;
    }
    int addMs = milli%1000;
    ms += addMs;
    if(ms >= 1000){
        ms -= 1000;
        second += 1;
        while(second >= 60){
            second -= 60;
            minute += 1;
            while(minute >= 60){
                minute -= 60;
                hour += 1;
                while(hour >= 24){
                    hour -= 24;
                    day += 1;
                    if(day > arr[month] || (month = 2 && year % 4 == 0 && day > arr[month] +1)){
                        day = 1;
                        month += 1;
                        if(month > 12){
                            year += 1;
                            month = 1;
                        }
                    }
                }
            }
        }
    }
}


