#ifndef DATATOUDP_H
#define DATATOUDP_H

#include <iostream>
#include <fstream>
#include <vector>

typedef struct pair {
    int board;
    int gate;
} pair;

class DataToUDP
{
public:
    DataToUDP(std::string filename);

    void generate_UDP();
    std::string interpret_date(std::string s);
    std::string interpret_time(std::string s);
    std::string interpret_bg(std::vector<struct pair> combo);
    void print_UDPs();

private:
    std::vector<std::string> hiveID;
    std::vector<std::string> date;
    std::vector<std::string> time;
    std::vector<std::vector<struct pair>> combos;
    std::vector<std::string> UDP;

};

#endif // DATATOUDP_H
