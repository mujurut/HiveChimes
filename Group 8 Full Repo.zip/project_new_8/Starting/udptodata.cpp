#include "udptodata.h"
#include "../database/datamanager.h"


/**
 * @brief UDPToData::UDPToData
 * This constructor reads in the filename of UDP messages to process
 * @param filename: The file to read UDP messages from
 */
UDPToData::UDPToData(string filename)
{
    fstream fileReader(filename);
    string baseString;
    while(fileReader >> baseString){
        processUDP(baseString);
    }
}

UDPToData::UDPToData(){

}

void UDPToData::linkDm(DataManager *d){
    dm = d;
}

/**
 * @brief UDPToData::processUDP
 * This function takes a UDP message in string form and turns it into a struct that holds all relevant values including date, time, and the signal
 * @param message: The message that needs to be processed
 */
void UDPToData::processUDP(string message){
    string HCstring = message.substr(2,4);
    string dateString = message.substr(7,23);
    string infoString = message.substr(31);
    int boardNum = 0;
    while(infoString.length() > 1){
        boardNum++;
        int countChar = 1;
        while(countChar != infoString.length() && infoString.at(countChar) != 'B'){
            countChar++;
        }
        int boardValue = stoi(infoString.substr(1,countChar));
        infoString = infoString.substr(countChar);

        if(boardValue == 0){
            continue;
        }
        for(int i = 0; i < 8; i++){
            bitset<8> originalValue(string(InfoToBin(boardValue)));
            if(originalValue[i]){
                UDPMessage newMessage;
                newMessage.hiveChime = stoi(HCstring);
                newMessage.dt.setUDPTimes(dateString);
                newMessage.board = boardNum;
                newMessage.value = boardValue;
                bitset<8> set(string(InfoToBin(pow(2,i))));
                newMessage.boardActivity = set;
                messages.push_back(newMessage);
            }
        }
    }
}

void UDPToData::liveProcess(string message){
    string HCstring = message.substr(2,4);
    string dateString = message.substr(7,21);
    string infoString = message.substr(29);
    int boardNum = 0;
    while(infoString.length() > 1){
        boardNum++;
        int countChar = 1;
        while(countChar != infoString.length() && infoString.at(countChar) != 'B'){
            countChar++;
        }
        int boardValue = stoi(infoString.substr(1,countChar));
        infoString = infoString.substr(countChar);

        if(boardValue == 0){
            continue;
        }
        for(int i = 0; i < 8; i++){
            bitset<8> originalValue(string(InfoToBin(boardValue)));
            if(originalValue[i]){
                UDPMessage newMessage;
                newMessage.hiveChime = stoi(HCstring);
                newMessage.dt.setUDPTimes(dateString);
                newMessage.board = boardNum;
                newMessage.value = boardValue;
                bitset<8> set(string(InfoToBin(pow(2,i))));
                newMessage.boardActivity = set;
                liveMessages.push_back(newMessage);
            }
        }
    }
}


/**
 * @brief UDPToData::InfoToBin
 * This function turns an integer from 1 to 255 into a bitset representation of it.
 * @param value: The value to convert to binary
 * @return The binary value as a string (which is parsed into a bitset)
 */
string UDPToData::InfoToBin(int value){
    string bitString;
    if(value >= 128){
        bitString += "1";
        value -= 128;
    }
    else{
        bitString += "0";
    }

    if(value >= 64){
        bitString += "1";
        value -= 64;
    }
    else{
        bitString += "0";
    }

    if(value >= 32){
        bitString += "1";
        value -= 32;
    }
    else{
        bitString += "0";
    }

    if(value >= 16){
        bitString += "1";
        value -= 16;
    }
    else{
        bitString += "0";
    }

    if(value >= 8){
        bitString += "1";
        value -= 8;
    }
    else{
        bitString += "0";
    }

    if(value >= 4){
        bitString += "1";
        value -= 4;
    }
    else{
        bitString += "0";
    }

    if(value >= 2){
        bitString += "1";
        value -= 2;
    }
    else{
        bitString += "0";
    }

    if(value == 1){
        bitString += "1";
    }
    else{
        bitString += "0";
    }
    return bitString;
}

void UDPToData::analysis(vector<UDPMessage> messages){
    swarmCheck.swarmCount = 0;
    swarmCheck.happened = false;
    ActivityStorage *currentTime = new ActivityStorage;
    currentTime->count = 0;
    currentTime->dt = messages.at(0).dt;
    for(int i = 0; i < messages.size()-1;i++){
        if(currentTime->dt.hour != messages.at(i).dt.hour || currentTime->dt.minute != messages.at(i).dt.minute){
            levels.push_back(*currentTime);
            currentTime = new ActivityStorage;
            currentTime->dt = messages.at(i).dt;
            currentTime->count = 0;
        }
        if(outCount > 50 && !swarmCheck.happened){
            swarmCheck.happened = true;
            swarmCheck.times.push_back(messages.at(i).dt);
            swarmCheck.swarmCount++;
        }
        bool timeCheck = true;
        if((messages.at(i).dt.compVal(messages.at(i+1).dt) > 1000 )){
            continue;
        }
        else{
            for(int j = i+1; timeCheck == true && j < messages.size(); j++){

                if(messages.at(i).board == messages.at(j).board && messages.at(i).dt.compVal(messages.at(j).dt) <= 1000){
                    for(int k = 0; k < 8; k++){
                        if(outCount > 50 && !swarmCheck.happened){
                            swarmCheck.happened = true;
                            swarmCheck.times.push_back(messages.at(i).dt);
                            swarmCheck.swarmCount++;
                        }
                        if(messages.at(i).scanned || messages.at(j).scanned){
                            continue;
                        }
                        else if(messages.at(i).boardActivity[k] && messages.at(j).boardActivity[7-k]){
                            UDPPairing p;
                            p.dt1 = messages.at(i).dt;
                            p.dt2 = messages.at(j).dt;
                            messages.at(i).scanned = true;
                            messages.at(j).scanned = true;
                            p.hiveChime = messages.at(i).hiveChime;
                            p.board = messages.at(i).board;
                            if(k <= 3){
                                p.entering = false;
                                outCount ++;
                                currentTime->count++;

                            }
                            else{
                                p.entering = true;
                                outCount--;
                                currentTime->count--;
                                if(outCount == -1){
                                    outCount = 0;
                                }
                            }
                            int boardBin;
                            int n = k;
                            if(k > 3){
                                n = 7-k;
                            }
                            switch (n){
                                case 0:
                                    boardBin = 129;
                                    break;
                                case 1:
                                    boardBin = 66;
                                    break;
                                case 2:
                                    boardBin = 36;
                                    break;
                                case 3:
                                    boardBin = 24;
                                    break;
                            }
                            bitset<8> t(string(InfoToBin(boardBin)));
                            p.boardPair = t;
                            pairings.push_back(p);
                            timeCheck = false;

                        }
                    }
                }
                else if(messages.at(i).dt.compVal(messages.at(j).dt) > 1000){
                    timeCheck = false;
                }
            }
            timeCheck = true;
        }
    }
    levels.push_back(*currentTime);
    for(CompDateTime t : swarmCheck.times){
        swarmDetect(t);
        this->dm->swarmTime = t;
    }
}



void UDPToData::swarmDetect(CompDateTime dt){
    std::cout<<"Swarm detected!"<<endl;
    std::cout<<"Time of swarm: " + dt.toUdpString()<<endl;
}

void UDPToData::goLive(vector<string> messages){
    for(string s : messages){
        liveProcess(s);
    }
    analysis(liveMessages);
    CompDateTime currentDateTime = liveMessages.at(liveMessages.size() - 1).dt;
    for(int i = 0; i < liveMessages.size(); i++){
        if(liveMessages.at(i).dt.compVal(currentDateTime) > 1000 || liveMessages.at(i).scanned){
            liveMessages.erase(liveMessages.begin()+i);
            i--;
        }
    }
}
