#ifndef BEEHIVEOWNER_H
#define BEEHIVEOWNER_H


class BeehiveOwner
{
public:
    BeehiveOwner();
};

#endif // BEEHIVEOWNER_H