#include "researcher.h"

Researcher::Researcher(): User::User()
{

}

Researcher::~Researcher(){

}

Researcher::Researcher(string firstName,string lastName,int iD): User::User()
{
    firstname = firstName;
    lastname = lastName;
    id = iD;
}
