#include "user.h"

User::User()
{

}

User::~User(){

}


User::User(string firstName,string lastName,int iD){
    firstname = firstName;
    lastname = lastName;
    id = iD;
}

string User::getFirstname(){
    return firstname;
}

string User::getLastname(){
    return firstname;
}

char User::getMiddleinitial(){
    return middleinitial;
}

string User::getId(){
    return id;
}

string User::getAddress(){
    return address;
}

int User::getPhonenumber(){
    return phonenumber;
}
