#include <iostream>
#include "udptodata.h"
#include "datatoudp.h"
#include "compdatetime.h"

int main()
{
    std::cout<<"\n\nPart 3:\n";
    DataToUDP* dtu;
    dtu = new DataToUDP("./info.txt");
    dtu->generate_UDP(2);
    std::cout<<"\n\n\nPart 4:\n";
    UDPToData data("udpMessages.txt");
    data.analysis(data.messages);
    std::cout<<data.messages.at(1).dt.toUdpString();
    std::cout<<"\n";
    std::cout<<data.messages.at(1).boardActivity;
    std::cout<<"\n";
    std::cout<<"\n";
    if(data.swarmCheck.happened){
        std::cout<<"Swarm happened at " + data.swarmCheck.times.at(0).toUdpString()<<endl;
    }
}
