#include "beehiveowner.h"

BeehiveOwner::BeehiveOwner(): User::User()
{

}

BeehiveOwner::~BeehiveOwner(){

}


BeehiveOwner::BeehiveOwner(string firstName,string lastName,int iD): User::User(){
    firstname = firstName;
    lastname = lastName;
    id = iD;
}
