#include "datatoudp.h"
#include "../database/datamanager.h"
/**
 * @brief DataToUDP::DataToUDP constructor that reads in an input file containing date, time (hour and minute),
 * and activity levels and stores them in the appropriate vectors
 * @param fname input file name
 */
DataToUDP::DataToUDP(std::string fname)
{

    count  = 0;
    swarm = false;
    std::ifstream f;
    f.open(fname);


    if (!f) {
        std::cerr << "file could not be opened" << std::endl;
        exit(1);
    } else {
        int i = 0;
        while (!f.eof()) {

            if (i == 3) { //resets counter
                i = 0;
            }

            std::string input;
            f >> input;

            if (i == 0) { //if first entry in line
                dates.push_back(input);
                std::cout << "date: " << input << std::endl;
            } else if (i == 1) { //if second
                std::cout << "time: " << input << std::endl;
                times.push_back(input);
            } else if (i == 2) { //if third
                std::cout << "l: " << input << std::endl;
                float l = stof(input);
                levels.push_back(l);
            }

            i++;

        }
    }
}

/**
 * @brief DataToUDP::linkDm
 * @param d
 */
void DataToUDP::linkDm(DataManager *d){
    this->dm = d;
}

/**
 * @brief DataToUDP::generate_intervals uses poisson and exponential distribution to generate a specific amount of
 * time intervals dictated by the activity level. It then concatantes the date and time from the input file with the
 * newly generated intervals, sorts the temporary vector, and then adds that vector to a vector of intervals
 */
void DataToUDP::generate_intervals() {
    int n;
    std::string inith;

    int initm;
    double fin;
    std::string time, t;
    std::default_random_engine gen(21072811);
    
    for (std::size_t i = 0; i < levels.size(); i++) { //generates activity level

        std::vector<std::string> temp;
        inith = times.at(i).substr(0,3);
        initm = stoi(times.at(i).substr(3, std::string::npos));

        if (levels.at(i) >= .5) { //sets swarm flag
            swarm = true;
        }
        else{
            swarm = false;
        }

        if(!swarm) {
            std::poisson_distribution<int> pd(levels.at(i)*BEEPOP);
            n = pd(gen);


            for (int j = 0; j < n; j++) { //generates a time interval in accordance to the activity level

                std::exponential_distribution<double> ed(n);
                double d = ed(gen);
                fin = initm+d; //minutes plus seconds
                if (fin < 10) {
                    t = "0"+(std::to_string(fin)).substr(0, 7); //truncate time to 5 digit milliseconds
                } else {
                    t = (std::to_string(fin)).substr(0, 8); //truncate time to 5 digit milliseconds
                }

                time = "D"+dates.at(i)+"T"+inith+t;
                temp.push_back(time);

            }
            if (temp.size()!=0) { //does not add temp to intervals if no time interval was generated
                temp = DataToUDP::sort_vector(temp);
                intervals.push_back(temp);
            }
        } else {
            temp.push_back("swarm");
            time = "D"+dates.at(i)+"T"+inith;
            if(initm < 10){
                time+= "0";
            }
            time += to_string(initm);
            time += to_string(levels.at(i)).substr(1);
            //time = "D"+dates.at(i)+"T"+inith+std::to_string(initm)+std::to_string(levels.at(i));
            temp.push_back(time);
            intervals.push_back(temp);
        }


    }

}

/**
 * @brief DataToUDP::generate_UDP uses a random generator to generate the board and gate number activated
 * at a specific time interval and concatenates the previously generated interval with the board/gate activation
 * representation to generate a UDP message which it then prints to console
 */
void DataToUDP::generate_UDP(int id) {
    int pairCount = 0;
    DataToUDP::generate_intervals();
    srand(1234);
    int board, gate, prob, opp;

    std::ofstream f;
    f.open("output.txt");
    for (std::size_t i = 0; i < intervals.size(); i++) {
        if (intervals.at(i).at(0).compare("swarm") !=0) {
            for (std::size_t j = 0; j < intervals.at(i).size(); j++) {
                bool pair = false;
                std::string UDP = "HC0001-";
                std::string UDP2 = "HC0001-";
                board = (rand() %10) + 1; //generate board number
                gate = (rand() %8) + 1; //generate gate number
                prob = (rand() %100) + 1;
                if (prob <=70) {
                    pair = true;
                    //generate pair
                    DataToUDP::opp_gate(gate, (intervals.at(i).at(j)).substr(0, 16), stoi((intervals.at(i).at(j)).substr(16, std::string::npos)));
                    opp = stoi(arr[0]);
                    UDP2+= arr[1];
                }
                UDP+= intervals.at(i).at(j) + "-";
                for (int k = 1; k <= 10; k++) {
                    if (k == board) {
                        UDP+=DataToUDP::binary_rep(gate);
                        if (pair) {
                            UDP2+=DataToUDP::binary_rep(opp);
                        }
                    } else {
                        UDP+="B0";
                        if (pair) {
                            UDP2+="B0";
                        }
                    }
                }


                udps.push_back(UDP); //stores generated UDP message in a vector
                f << UDP << std::endl;
                count++;
                if (pair) {
                    udps.push_back(UDP2);
                    f << UDP2 << std::endl;
                    pairCount++;
                    count++;
                }

            }

        } else { //if generate swarm, generates swarm
            std::string UDP = "HC0001-"+(intervals.at(i).at(1)).substr(0, 15);
            float f = stof((intervals.at(i).at(1)).substr(15, std::string::npos));
            DataToUDP::generate_swarm(UDP, f, id);
        }
    }
    udps = this->sort_vector(udps);
    dm->addScenario("test",5,5,udps,id);
    dm->selectScenario(id);
    for(std::string s : udps){
        std::cout<<s<<"\n";
    }
    f.close();
    std::cout<<pairCount;
}

/**
 * @brief DataToUDP::generate_swarm generates swarming event
 */
void DataToUDP::generate_swarm(std::string s, float f, int id) {

    std::string udp, udp2;
    int count = BEEPOP*f;
    int interval = 59999/count;
    int time = 100000;
    srand(1234);

    for (int i = 0; i < count; i++) {
        udp = s;
        udp2 = s + ".";
        time+=interval;
        std::string t = std::to_string(time).substr(1, std::string::npos);
        udp+="."+t+"-";
        int gate = (rand() % 4) + 1;
        int board = (rand()%10) + 1;
        int opp;
        DataToUDP::opp_gate(gate, udp2, stoi(t));
        opp = stoi(arr[0]);
        udp2 = arr[1];
        for (int k = 1; k <= 10; k++) {
            if (k == board) {
                udp+=DataToUDP::binary_rep(gate);
                udp2+=DataToUDP::binary_rep(opp);
            } else {
                udp+="B0";
                udp2+="B0";
                }
            }

        udps.push_back(udp);
        udps.push_back(udp2);
    }

}

void DataToUDP::opp_gate(int gate, std::string s1, int s2) {

    int opp = 0;
    std::string s = "";

    switch(gate) {
    case 1:
        opp = 8;
        break;
    case 2:
        opp = 7;
        break;
    case 3:
        opp = 6;
        break;
    case 4:
        opp = 5;
        break;
    case 5:
        opp = 4;
        break;
    case 6:
        opp = 3;
        break;
    case 7:
        opp = 2;
        break;
    case 8:
        opp = 1;
        break;
    default:
        std::cerr << "error." << std::endl;
    }
    int temp;
    s+= s1;
    temp = s2;
    temp += 1000;
    if (temp/10000.0 < 1 && temp/10000.0 > 0) {
        s+="0"+std::to_string(temp)+"-";
    } else {
        s+=std::to_string(temp)+"-";
    }

    arr[0] = std::to_string(opp);
    arr[1] = s;

}

/**
 * @brief DataToUDP::get_udps returns the udp messages
 * @return vector of UDP messages
 */
std::vector<std::string> DataToUDP::get_udps() {
    return udps;
}

/**
 * @brief DataToUDP::sort_vector takes in a vector and sorts it from smallest value to largest
 * @param v vector of strings
 * @return sorted v
 */
std::vector<std::string> DataToUDP::sort_vector(std::vector<std::string> v) {
    std::size_t i, j, min_i;

    for (i = 0; i < (v.size()-1); i++) {
        min_i = i;

        for (j = i+1; j < v.size(); j++) {

            if (v.at(j).compare(v.at(min_i)) < 0) {
                min_i = j;
            }

        }
        std::swap(v.at(min_i), v.at(i));
    }

    return v;

}

/**
 * @brief DataToUDP::binary_rep uses a bitset of size 8 to represent which gate has been activated
 * @param n gate number
 * @return string representation of board and gate
 */
std::string DataToUDP::binary_rep(int n) {
    int b = 0b11111111;
    switch (n) {
        case 1:
            b = b&0b00000001;
            break;
        case 2:
            b = b&0b00000010;
            break;
        case 3:
            b = b&0b00000100;
            break;
        case 4:
            b = b&0b00001000;
            break;
        case 5:
            b = b&0b00010000;
            break;
        case 6:
            b = b&0b00100000;
            break;
        case 7:
            b = b&0b01000000;
            break;
        case 8:
            b = b&0b10000000;
            break;
        default:
            std::cerr<<"invalid input"<<std::endl;

    }

    return "B"+std::to_string(b);
}

