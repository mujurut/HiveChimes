#include "WRONG.h"

DataToUDP::DataToUDP(std::string filename)
{
    std::ifstream f;
    f.open(filename);

    if (!f) {
        std::cerr << "unable to open file";
    } else {

        while (!f.eof()) {

            std::string input;
            f >> input;

            if (input.compare("hiveID") == 0) {

                f >> input;
                hiveID.push_back(input);

            } else if (input.compare("date") == 0) {

                f >> input;
                date.push_back(input);

            } else if (input.compare("time") == 0) {

                f >> input;
                time.push_back(input);

            } else if (input.compare("board") == 0) {

                std::vector<struct pair> v;


                std::cout << input <<std::endl;
                //while (!(input.compare("hiveID") == 0)) {

                    int b;
                    f >> input;
                    b = std::stoi(input);
                    std::cout << "b: " << b << std::endl;

                    int g;
                    f >> input;
                    std::cout << "input: " << input <<std::endl;
                    if (!(input.compare("gate") == 0)) {
                        std::cerr << "wrong file format" << std::endl;
                        exit(1);
                    } else {
                        f >> input;
                        g = std::stoi(input);
                    }

                    struct pair bg = {b, g};
                    v.push_back(bg);

                //}
                combos.push_back(v);
            }

        }

    }
}

void DataToUDP::generate_UDP() {

    if (hiveID.size() != date.size() && hiveID.size() != time.size() && hiveID.size() != combos.size()) {

        std::cerr << "input file was not correctly formatted. change and try again" << std::endl;
        exit(1);

    } else {

        std::string udp = "";
        for (std::size_t i = 0; i < hiveID.size(); i++) {
            udp+=hiveID.at(i) + "-";
            udp+=DataToUDP::interpret_date(date.at(i));
            udp+=DataToUDP::interpret_time(time.at(i)) + "-";
            udp+=DataToUDP::interpret_bg(combos.at(i));
        }

        std::cout << udp << std::endl;
    }
}

std::string DataToUDP::interpret_date(std::string s) {

    std::string d = "D";

    std::string date[3];
    date[0] = s.substr(0,2);
    date[1] = s.substr(3,2);
    date[2] = s.substr(6,2);
    d += date[0] + "." + date[1] + "." + date[2];

    return d;

}

std::string DataToUDP::interpret_time(std::string s) {

    std::string t = "T";

    std::string time[3];
    time[0] = s.substr(0,2);
    time[1] = s.substr(3,2);
    time[2] = s.substr(6,2);
    t += time[0] + "." + time[1] + "." + time[2];

    return t;

}

std::string DataToUDP::interpret_bg(std::vector<struct pair> combo) {

    std::string bg = "";

    std::vector<int> b;

    for (std::size_t i = 0; i < combo.size(); i++) {
        b.push_back(combo.at(i).board);
    }

    for (int i = 1; i < 11; i++) {
        if (i == b.at(0)) {
            //bg+=
        }
    }

    return bg;

}


