#ifndef RESEARCHER_H
#define RESEARCHER_H


class Researcher
{
public:
    Researcher();
};

#endif // RESEARCHER_H