#ifndef UDPTODATA_H
#define UDPTODATA_H
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <chrono>
#include "compdatetime.h"
#include <bitset>
#include <cmath>

using namespace std;


typedef struct UDPMessage{
    CompDateTime dt;
    int hiveChime;
    int board;
    int value;
    bitset<8> boardActivity;
    bool scanned;
    string originalMessage;
} UDPMessage;

typedef struct Swarm{
    vector<CompDateTime> times;
    int swarmCount;
    bool happened;
} Swarm;

typedef struct UDPPairing{
    CompDateTime dt1;
    CompDateTime dt2;
    int hiveChime;
    int board;
    bool entering;
    bitset<8> boardPair;
} UDPPairing;

typedef struct ActivityStorage{
    CompDateTime dt;
    int count;
} ActivityStorage;

class DataManager;


class UDPToData
{
public:
    UDPToData();
    UDPToData(string filename);
    void processUDP(string message);
    DataManager *dm;
    void linkDm(DataManager *d);
    vector<UDPMessage> messages;
    string InfoToBin(int value);
    vector<UDPPairing> pairings;
    void analysis(vector<UDPMessage> messages);
    void liveAnalysis(vector<UDPMessage> messages);
    void liveProcess(string message);
    int outCount = 0;
    void swarmDetect(CompDateTime dt);
    Swarm swarmCheck;
    vector<ActivityStorage> levels;
    vector<UDPMessage> liveMessages;
    void goLive(vector<string> messages);
};

#endif // UDPTODATA_H
