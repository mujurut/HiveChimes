#ifndef DATATOUDP_H
#define DATATOUDP_H

#define BEEPOP 100

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <vector>
#include <random>
#include <string.h>
#include <bitset>
class DataManager;

class DataToUDP
{
public:
    DataToUDP();
    DataToUDP(std::string filename);

    void generate_intervals();
    void generate_UDP(int id);
    void generate_swarm(std::string s, float f, int id);
    std::vector<std::string> get_udps();
    void linkDm(DataManager *d);
    DataManager *dm;


private:
    std::vector<std::string> dates;
    std::vector<std::string> times;
    std::vector<float> levels;
    std::vector<std::vector<std::string>> intervals;
    std::vector<std::string> udps;
    int count;
    bool swarm;

    std::string arr[2];


    std::vector<std::string> sort_vector(std::vector<std::string> v);
    std::string binary_rep(int n);
    void opp_gate(int gate, std::string s1, int s2);




};

#endif // DATATOUDP_H
