#ifndef RATE_H
#define RATE_H

#include <QMainWindow>
#include <QtCore>
#include <QDebug>
#include <vector>
using namespace std;
namespace Ui {
class rate;
}

class rate : public QMainWindow
{
    Q_OBJECT
    QTimer *timer;
    long timeTracker;
    long timeStep = 100;
    vector<int> times = {2500,4000,4200,4400,7000,7100,7900,8100,8800};
    vector<int> saves;

    public:
        explicit rate(QWidget *parent = nullptr);
        ~rate();
    public slots:
        void mySlot();

    private:
        Ui::rate *ui;
};

#endif // RATE_H
