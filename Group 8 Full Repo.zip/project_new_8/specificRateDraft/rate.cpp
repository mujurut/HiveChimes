#include "rate.h"
#include "ui_rate.h"

rate::rate(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::rate)
{
    ui->setupUi(this);
    timeTracker = 0;
    saves = {};

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(mySlot()));
    timer -> start(timeStep);
    //timer -> start(500);
}

rate::~rate()
{
    delete ui;
}

void rate::mySlot()
{
    for(int time_i : times)
    {
        if(time_i >= timeTracker && time_i < timeTracker + timeStep)
        {
            saves.push_back(time_i);
            qDebug() << time_i;
        }
    }
    timeTracker += timeStep;
}
