#ifndef UDPTABLE_H
#define UDPTABLE_H
#include "dbtable.h"
#include "dbtool.h"
#include "../Starting/udptodata.h"
#include "../database/sqlite-amalgamation-3270200/sqlite3.h"
#include <string>

using namespace std;

class DataManager;

class UDPTable : public DBTable
{
protected:
    string sql_select_all;
    string sql_add_row;
    string hiveSelect;
public:
    UDPTable();
    UDPTable(DBTool *db, string name);

    ~UDPTable();

    void linkManager(DataManager *d);

    DataManager *dm;

    void store_create_sql();
    virtual void store_add_row_sql();
    bool add_row(string udp, int sID);
    bool select_all();
    bool parse_add_udp(string udp);
    bool select_hive(int hiveID, int lastSaved);
    bool select_scen(int scenID);
    UDPMessage toUDP(string x);
};

#endif // UDPTABLE_H

int cb_add_row_udp(void *data,
               int argc,
               char **argv,
               char **azColName);

int cb_select_all_udp(void *data,
                  int argc,
                  char **argv,
                  char **azColName);

int cb_select_hive_udp(void *data,
                  int argc,
                  char **argv,
                  char **azColName);

int cb_select_scen_udp(void *data,
                  int argc,
                  char **argv,
                  char **azColName);

