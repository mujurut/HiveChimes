#ifndef CURRENTSCENTABLE_H
#define CURRENTSCENTABLE_H
#include "dbtable.h"
#include "dbtool.h"
using namespace std;

class DataManager;


class CurrentScenTable : public DBTable
{
protected:
    string sql_select_all;
    string sql_add_row;
public:
    CurrentScenTable();
    CurrentScenTable(DBTool *db, string name);

    ~CurrentScenTable();

    void linkManager(DataManager *d);

    DataManager *dm;

    void store_create_sql();
    virtual void store_add_row_sql();
    bool select_all();
    bool add_row(string udp, int rID);
    void empty_table();
};

int cb_add_row_udp(void *data,
               int argc,
               char **argv,
               char **azColName);

int cb_select_all_udp(void *data,
                  int argc,
                  char **argv,
                  char **azColName);

int cb_add_row_currScen(void  *data,
               int    argc,
               char **argv,
               char **azColName);

#endif // CURRENTSCENTABLE_H
