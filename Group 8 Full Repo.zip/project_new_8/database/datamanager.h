#ifndef DATAMANAGER_H
#define DATAMANAGER_H
#include <vector>
#include <chrono>
#include "dbtool.h"
#include "dbtable.h"
#include "chimetable.h"
#include "hivetable.h"
#include "scenariotable.h"
#include "udptable.h"


class ChimeTable;
class ScenarioTable;
class HiveTable;
class UDPTable;
class CurrentScenTable;

typedef struct Scenario{
    int id;
    std::string definition;
    float latitude;
    float longitude;
    string date;
}Scenario;

class DataToUDP;

class DataManager
{
public:
    DataManager();

    //Tables
    HiveTable *hTable;
    ScenarioTable *sTable;
    ChimeTable *cTable;
    UDPTable *uTable;
    CurrentScenTable *rTable;
    DBTool *dbtool;
    DataToUDP *dtu;
    UDPToData *utd;

    vector<Scenario> scenVector;
    vector<UDPMessage> currentRun;
    vector<string> nameTest;
    void addNameTest(int size, char **data, char **colNames);
    void scenVecAdd(int size, char **data, char **colNames);
    void selectScenario(int runID);
    string InfoToBin(int value);
    void analysis();
    void generateUDP(int y);
    void addCurrentMessage(string x, int rID);
    int GetScenID(string input);
    void setDTU(string filename);
    void addMessage(string message, int id);
    void addScenario(string desc, float x, float y, vector<string>, int runID);
    void addUDPMessage(string mess, float x, float y, vector<string>);
    UDPMessage toUDPFormat(string x);
    CompDateTime swarmTime;
};

#endif // DATAMANAGER_H
