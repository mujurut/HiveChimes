#include <iostream>
#include "datamanager.h"

using namespace std;

int main()
{
    DataManager d;
    d.sTable->add_row("Test description",2,2,2);

    d.setDTU("./info.txt");
    d.generateUDP(4);
    int x = 5;
}
