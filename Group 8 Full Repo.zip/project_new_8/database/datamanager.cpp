#include "datamanager.h"
#include "hivetable.h"
#include "chimetable.h"
#include "udptable.h"
#include "scenariotable.h"
#include "currentscentable.h"
#include "../Starting/datatoudp.h"
#include "../Starting/udptodata.h"

DataManager::DataManager()
{
    dbtool = new DBTool("BeeProjectTableFinal.sqlite");
    hTable = new HiveTable(dbtool, "TableHive");
    uTable = new UDPTable(dbtool, "TableUDP");
    sTable = new ScenarioTable(dbtool, "TableScenario");
    cTable = new ChimeTable(dbtool, "TableChime");
    rTable = new CurrentScenTable(dbtool, "TableScenCurrent");
    hTable->linkManager(this);
    uTable->linkManager(this);
    sTable->linkManager(this);
    cTable->linkManager(this);
    rTable->linkManager(this);
    sTable->select_all();
    rTable->select_all();
    //dtu = new DataToUDP("info.txt");
    //dtu->linkDm(this);
}

/**
 * @brief DataManager::GetScenID
 * This method will eventually get the ID of a specified scenario
 * @param a string that represents the parameter of the scenario to look for
 * @return an int which corresponds to the scenario
 *
 * Right now the functionality is not complete because I haven't had time to fully implement it
 * and I'm not sure if we 100% need it
 */

/**
 * @brief addScenario adds the UDP messages from a scenario to the database
 * @param a string representing a description, two floats
 * representing the latitude and longitude, and a vector of strings of UDP messages
 * The case is added to the database(UDPTable and ScenarioTable)
 */

void DataManager::setDTU(string filename){
    dtu = new DataToUDP(filename);
    dtu->linkDm(this);
}

void DataManager::analysis(){
    utd = new UDPToData();
    utd->linkDm(this);
    utd->analysis(currentRun);
}

void DataManager::generateUDP(int y){
    dtu->generate_UDP(y);
}

void DataManager::addNameTest(int size, char **data, char **colNames){
    for(int i = 0; i < size; i++){

    }
    string fName = std::string(data[1]);
    nameTest.push_back(fName);
}

void DataManager::addScenario(string desc, float x, float y, vector<string> messages, int runID){
    int run = runID;
    for(string s : messages){
        uTable->add_row(s,run);
    }
    sTable->add_row(desc, x, y, run);
}

void DataManager::scenVecAdd(int size, char **data, char **colNames){
    Scenario *s = new Scenario;
    s->id = std::atoi(data[0]);
    s->definition = data[1];
    s->date = data[2];
    s->latitude = atof(data[3]);
    s->longitude = atof(data[4]);
    scenVector.push_back(*s);
}

void DataManager::selectScenario(int runID){
    rTable->empty_table();
    rTable = new CurrentScenTable(dbtool, "TableScenCurrent");
    uTable->select_scen(runID);
}

void DataManager::addMessage(string message, int id){
    uTable->add_row(message,id);
}

UDPMessage DataManager::toUDPFormat(string x){
    string HCstring = x.substr(2,4);
    string dateString = x.substr(7,21);
    string infoString;
    try {
        infoString = x.substr(29);
    } catch (exception) {
        infoString = "B0B0B0B0B0B0B0B0B0B0";
    }
    int boardNum = 0;
    while(infoString.length() > 1){
        boardNum++;
        int countChar = 1;
        while(countChar != infoString.length() && infoString.at(countChar) != 'B'){
            countChar++;
        }
        int boardValue = stoi(infoString.substr(1,countChar));
        infoString = infoString.substr(countChar);

        if(boardValue == 0){
            continue;
        }
        for(int i = 0; i < 8; i++){
            bitset<8> originalValue(string(InfoToBin(boardValue)));
            if(originalValue[i]){
                UDPMessage newMessage;
                newMessage.hiveChime = stoi(HCstring);
                newMessage.dt.setUDPTimes(dateString);
                newMessage.board = boardNum;
                newMessage.value = boardValue;
                newMessage.originalMessage = x;
                bitset<8> set(string(InfoToBin(pow(2,i))));
                newMessage.boardActivity = set;
                newMessage.scanned = false;
                return newMessage;
            }
        }
    }
}

string DataManager::InfoToBin(int value){
    string bitString;
    if(value >= 128){
        bitString += "1";
        value -= 128;
    }
    else{
        bitString += "0";
    }

    if(value >= 64){
        bitString += "1";
        value -= 64;
    }
    else{
        bitString += "0";
    }

    if(value >= 32){
        bitString += "1";
        value -= 32;
    }
    else{
        bitString += "0";
    }

    if(value >= 16){
        bitString += "1";
        value -= 16;
    }
    else{
        bitString += "0";
    }

    if(value >= 8){
        bitString += "1";
        value -= 8;
    }
    else{
        bitString += "0";
    }

    if(value >= 4){
        bitString += "1";
        value -= 4;
    }
    else{
        bitString += "0";
    }

    if(value >= 2){
        bitString += "1";
        value -= 2;
    }
    else{
        bitString += "0";
    }

    if(value == 1){
        bitString += "1";
    }
    else{
        bitString += "0";
    }
    return bitString;
}

void DataManager::addCurrentMessage(string x, int rID){
    rTable->add_row(x, rID);
    UDPMessage *m = new UDPMessage;
    *m = toUDPFormat(x);

    currentRun.push_back(*m);
}
