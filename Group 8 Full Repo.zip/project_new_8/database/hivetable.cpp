#include "hivetable.h"
#include "datamanager.h"

HiveTable::HiveTable()
{

}

HiveTable::HiveTable(DBTool *db, string name) : DBTable(db,name){
    store_add_row_sql();
    store_create_sql();
    build_table();
}

HiveTable::~HiveTable(){

}

void HiveTable::linkManager(DataManager *d){
    this->dm = d;
}

void HiveTable::store_add_row_sql(){
    sql_template = "SELECT name ";
    sql_template += "FROM sqlite_master ";
    sql_template += "WHERE";
    sql_template += "     type  = \"table\"";
    sql_template += ";";
}

void HiveTable::store_create_sql(){
    sql_create = "CREATE TABLE ";
    sql_create += table_name;
    sql_create += " ( ";
    sql_create += "  ID INTEGER PRIMARY KEY AUTOINCREMENT, ";
    sql_create += "  FNAME TEXT NOT NULL,";
    sql_create += "  LNAME TEXT NOT NULL,";
    sql_create += "  MINIT CHAR, ";
    sql_create += "  LATITUDE FLOAT NOT NULL, ";
    sql_create += "  LONGITUDE FLOAT NOT NULL);";
}

bool HiveTable::add_row(string fName, string lName, char mInit, float lat, float lon){
    int retCode = 0;
    char *zErrMsg = 0;
    char tempval[128];

    sql_add_row = "INSERT INTO ";
    sql_add_row += table_name;
    sql_add_row += " (FNAME, LNAME, MINIT, LATITUDE, LONGITUDE) ";
    sql_add_row += "VALUES (\"";

    sql_add_row += fName;
    sql_add_row += "\", \"";

    sql_add_row += lName;
    sql_add_row += "\" ,";

    sql_add_row += to_string(mInit);
    sql_add_row += ", ";

    sql_add_row += to_string(lat);
    sql_add_row += ", ";

    sql_add_row += to_string(lon);
    sql_add_row += ");";

    retCode = sqlite3_exec(curr_db->db_ref(),sql_add_row.c_str(),cb_add_row_hive,this,&zErrMsg);
    if(retCode != SQLITE_OK ){
        std::cerr <<table_name
                 << " template ::"
                 << std::endl
                 << "SQL error: "
                 << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}


int cb_add_row_hive(void  *data,
               int    argc,
               char **argv,
               char **azColName)
{



    std::cerr << "cb_add_row being called\n";

    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    HiveTable *obj = (HiveTable *) data;

    std::cout << "------------------------------\n";
    std::cout << obj->get_name()
              << std::endl;

    for(i = 0; i < argc; i++){
        std::cout << azColName[i]
                  << " = "
                  <<  (argv[i] ? argv[i] : "NULL")
                  << std::endl;
    }

    return 0;
}

int cb_select_all_hive(void  *data,
                  int    argc,
                  char **argv,
                  char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    HiveTable *obj = (HiveTable *) data;
    if(obj->dm != nullptr){
        obj->dm->addNameTest(argc, argv, azColName);
    }


    return 0;
}


bool HiveTable::select_all(){
    int retCode = 0;
    char *zErrMsg = 0;

    sql_select_all  = "SELECT * FROM ";
    sql_select_all += table_name;
    sql_select_all += ";";

    retCode = sqlite3_exec(curr_db->db_ref(),
                           sql_select_all.c_str(),
                           cb_select_all_hive,
                           this,
                           &zErrMsg            );
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}
