#ifndef HIVETABLE_H
#define HIVETABLE_H
#include "dbtable.h"
#include "dbtool.h"
using namespace std;

class DataManager;

class HiveTable : public DBTable
{
protected:
    string sql_select_all;
    string sql_add_row;
public:
    HiveTable();
    HiveTable(DBTool *db, string name);

    ~HiveTable();

    void linkManager(DataManager *d);

    DataManager *dm;

    void store_create_sql();
    virtual void store_add_row_sql();
    bool select_all();
    bool add_row(string fName, string lName, char mInit, float lat, float lon);
};

#endif // HIVETABLE_H

int cb_add_row_hive(void *data,
               int argc,
               char **argv,
               char **azColName);

int cb_select_all_hive(void *data,
                  int argc,
                  char **argv,
                  char **azColName);
