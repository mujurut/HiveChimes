#include "scenariotable.h"
#include "datamanager.h"

ScenarioTable::ScenarioTable()
{

}

ScenarioTable::ScenarioTable(DBTool *db, string name) : DBTable (db,name){
    store_add_row_sql();
    store_create_sql();
    build_table();
}

ScenarioTable::~ScenarioTable(){

}

void ScenarioTable::linkManager(DataManager *d){
    this->dm = d;
}

void ScenarioTable::store_add_row_sql(){
    sql_template = "SELECT name ";
    sql_template += "FROM sqlite_master ";
    sql_template += "WHERE";
    sql_template += "     type  = \"table\"";
    sql_template += ";";
}

void ScenarioTable::store_create_sql(){
    sql_create = "CREATE TABLE ";
    sql_create += table_name;
    sql_create += " ( ";
    sql_create += " ID INTEGER PRIMARY KEY AUTOINCREMENT, ";
    sql_create += " DESCRIPTION TEXT NOT NULL, ";
    sql_create += " DATE DATE NOT NULL, ";
    sql_create += " LATITUDE FLOAT NOT NULL, ";
    sql_create += " LONGITUDE FLOAT NOT NULL);";
}

bool ScenarioTable::add_row(string desc, float lat, float lon, int id){
    int retCode = 0;
    char *zErrMsg = 0;
    char tempval[128];

    sql_add_row = "INSERT INTO ";
    sql_add_row += table_name;
    sql_add_row += " (DESCRIPTION, DATE, LATITUDE, LONGITUDE) ";
    sql_add_row += "Values (\"";


    sql_add_row += desc;
    sql_add_row += "\", ";

    sql_add_row += "date('now'),";

    sql_add_row += to_string(lat);
    sql_add_row += ", ";

    sql_add_row += to_string(lon);
    sql_add_row += ");";

    retCode = sqlite3_exec(curr_db->db_ref(),sql_add_row.c_str(),cb_add_row_scen,this,&zErrMsg);
    if(retCode != SQLITE_OK ){
        std::cerr <<table_name
                 << " template ::"
                 << std::endl
                 << "SQL error: "
                 << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}

bool ScenarioTable::select_all(){
    int retCode = 0;
    char *zErrMsg = 0;

    sql_select_all  = "SELECT * FROM ";
    sql_select_all += table_name;
    sql_select_all += ";";

    retCode = sqlite3_exec(curr_db->db_ref(),
                           sql_select_all.c_str(),
                           cb_select_all_scen,
                           this,
                           &zErrMsg            );
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}


/**
 * @brief ScenarioTable::getScen
 * This (theoretically) would return the scenario specified by the id.
 * @param id
 * @return
 */
bool ScenarioTable::getScen(int id){
    int retCode = 0;
    char *zErrMsg = 0;

    string sql_get_scen = "SELECT * FROM ";
    sql_get_scen += table_name;
    sql_get_scen += "WHERE ID=";
    sql_get_scen += to_string(id);
    sql_get_scen += ";";

    retCode = sqlite3_exec(curr_db->db_ref(),
                            sql_get_scen.c_str(),
                           cb_select_all_scen,
                           this,
                           &zErrMsg);
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);

    }
    return retCode;
}

int cb_add_row_scen(void  *data,
               int    argc,
               char **argv,
               char **azColName)
{



    std::cerr << "cb_add_row being called\n";

    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    ScenarioTable *obj = (ScenarioTable *) data;



    return 0;
}

int cb_select_all_scen(void  *data,
                  int    argc,
                  char **argv,
                  char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    ScenarioTable *obj = (ScenarioTable *) data;
    if(obj->dm != nullptr){
        obj->dm->scenVecAdd(argc, argv, azColName);
    }
    return 0;
}


