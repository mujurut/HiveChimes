#include "udptable.h"
#include "datamanager.h"

UDPTable::UDPTable()
{

}


UDPTable::UDPTable(DBTool *db, string name) : DBTable(db,name){
    store_add_row_sql();
    store_create_sql();
    build_table();
}

UDPTable::~UDPTable(){

}

UDPMessage UDPTable::toUDP(string x){
    return dm->toUDPFormat(x);
}

void UDPTable::linkManager(DataManager *d){
    this->dm = d;
}

void UDPTable::store_add_row_sql(){
    sql_template = "SELECT name ";
    sql_template += "FROM sqlite_master ";
    sql_template += "WHERE";
    sql_template += "     type  = \"table\"";
    sql_template += ";";
}

void UDPTable::store_create_sql(){
    sql_create = "CREATE TABLE ";
    sql_create += table_name;
    sql_create += " ( ";
    sql_create += "  ID INTEGER PRIMARY KEY AUTOINCREMENT, ";
    sql_create += "  MSG TEXT NOT NULL, ";
    sql_create += "  RUNID INTEGER NOT NULL);";
}

/**
 * @brief UDPTable::parse_add_udp
 * I don't really remember what this is. From what I remember, I was going to use this
 * but I held off on it because it would have required the UDPMessage struct
 * @param udp
 * @return
 */
bool UDPTable::parse_add_udp(string udp){
    int hiveId;
    string timeStamp;
}

bool UDPTable::add_row(string udp, int sID){
    int retCode = 0;
    char *zErrMsg = 0;
    char tempval[128];

    sql_add_row = "INSERT INTO ";
    sql_add_row += table_name;
    sql_add_row += " (MSG, RUNID) ";
    sql_add_row += "Values (\"";



    sql_add_row += string(udp);
    sql_add_row += "\", ";
    sql_add_row += to_string(sID);
    sql_add_row += ");";

    retCode = sqlite3_exec(curr_db->db_ref(),sql_add_row.c_str(),cb_add_row_udp,this,&zErrMsg);
    if(retCode != SQLITE_OK ){
        std::cerr <<table_name
                 << " template ::"
                 << std::endl
                 << "SQL error: "
                 << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}

int cb_add_row_udp(void  *data,
               int    argc,
               char **argv,
               char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    UDPTable *obj = (UDPTable *) data;

    std::cout << "------------------------------\n";
    std::cout << obj->get_name()
              << std::endl;

    for(i = 0; i < argc; i++){
        std::cout << azColName[i]
                  << " = "
                  <<  (argv[i] ? argv[i] : "NULL")
                  << std::endl;
    }

    return 0;
}

int cb_select_all_udp(void  *data,
                  int    argc,
                  char **argv,
                  char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    UDPTable *obj = (UDPTable *) data;

    std::cout << "------------------------------\n";
    std::cout << obj->get_name()
              << std::endl;

    for(i = 0; i < argc; i++){
        std::cout << azColName[i]
                  << " = "
                  <<  (argv[i] ? std::string(argv[i]) : "NULL")
                  << std::endl;
    }

    return 0;
}

int cb_select_hive_udp(void  *data,
                  int    argc,
                  char **argv,
                  char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    UDPTable *obj = (UDPTable *) data;

    std::cout << "------------------------------\n";
    std::cout << obj->get_name()
              << std::endl;

    for(i = 0; i < argc; i++){
        std::cout << azColName[i]
                  << " = "
                  <<  (argv[i] ? std::string(argv[i]) : "NULL")
                  << std::endl;
    }

    return 0;
}


bool UDPTable::select_all(){
    int retCode = 0;
    char *zErrMsg = 0;

    sql_select_all  = "SELECT * FROM ";
    sql_select_all += table_name;
    sql_select_all += ";";

    retCode = sqlite3_exec(curr_db->db_ref(),
                           sql_select_all.c_str(),
                           cb_select_all_udp,
                           this,
                           &zErrMsg            );
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}

/**
 * @brief UDPTable::select_hive
 * This (also theoretically) will access all the codes from a specific hive. This also adds
 * the possibility of using a save file on the device, using a "Last Saved" value that is updated
 * on the device each time that device accesses the database.
 * Similar functionality could be used to get a specific scenario by using the scenID value
 * @param hiveID
 * @param lastSaved
 * @return
 */

bool UDPTable::select_scen(int scenID){
    int retCode = 0;
    char *zErrMsg = 0;

    hiveSelect = "SELECT * FROM ";
    hiveSelect += table_name;
    hiveSelect += " WHERE RUNID=";
    hiveSelect += to_string(scenID);
    hiveSelect += ";";

    retCode = sqlite3_exec(curr_db->db_ref(),
                           hiveSelect.c_str(),
                           cb_select_scen_udp,
                           this,
                           &zErrMsg            );
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}

int cb_select_scen_udp(void  *data,
                  int    argc,
                  char **argv,
                  char **azColName)
{




    if(argc < 1) {
        std::cerr << "No data presented to callback "
                  << "argc = " << argc
                  << std::endl;
    }

    int i;

    UDPTable *obj = (UDPTable *) data;
    obj->dm->addCurrentMessage(argv[1],atoi(argv[2]));
    //m = UDPTable::toUDP(argv[1]);


    return 0;
}

bool UDPTable::select_hive(int hiveID, int lastSaved){
    int retCode = 0;
    char *zErrMsg = 0;

    hiveSelect = "SELECT * FROM ";
    hiveSelect += table_name;
    hiveSelect += " WHERE HIVEID=";
    hiveSelect += to_string(hiveID);
    hiveSelect += " AND ID>";
    hiveSelect += to_string(lastSaved);
    hiveSelect += ";";//Change to save the id of the last UDP message to the end of the file

    retCode = sqlite3_exec(curr_db->db_ref(),
                           hiveSelect.c_str(),
                           cb_select_hive_udp,
                           this,
                           &zErrMsg            );
    if(retCode != SQLITE_OK){
        std::cerr << table_name
                  << " template ::"
                  << std::endl
                  << "SQL error: "
                  << zErrMsg;
        sqlite3_free(zErrMsg);
    }
    return retCode;
}
//Any messages that are sent to the device using this function and are less than the limit of how long it takes a bee to pass through the gate should be
//held somewhere in the device that will not be analyzed until the function is refreshed (and it's been over the time limit)



