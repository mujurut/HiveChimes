#ifndef SCENARIOTABLE_H
#define SCENARIOTABLE_H
#include "dbtable.h"
#include "dbtool.h"
using namespace std;

class DataManager;

class ScenarioTable : public DBTable
{
protected:
    string sql_select_all;
    string sql_add_row;
public:
    ScenarioTable();
    ScenarioTable(DBTool *db, string name);

    ~ScenarioTable();

    void linkManager(DataManager *d);

    DataManager *dm;

    void store_create_sql();
    virtual void store_add_row_sql();
    bool getScen(int id);
    bool select_all();
    bool add_row(string desc, float lat, float lon, int id);
};


#endif // SCENARIOTABLE_H

int cb_add_row_scen(void *data,
               int argc,
               char **argv,
               char **azColName);

int cb_select_all_scen(void *data,
                  int argc,
                  char **argv,
                  char **azColName);
