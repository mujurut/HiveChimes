#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    analytics = new UDPToData;
    ui->setupUi(this);
    mng = new QNetworkAccessManager(this);
    connect(mng, SIGNAL(finished(QNetworkReply*)),this, SLOT(mng_finished(QNetworkReply*)));
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this,SLOT(get_UDP_from_web()));
    timer->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::get_UDP_from_web(){
    request.setUrl(QUrl("http://tomcollinsresearch.net/research/rpa/fakeudp/fakeudpmgate.html"));
    request.setRawHeader("User-Agent","MyOwnBrowser 1.0");
    mng->get(request);
}

void MainWindow::mng_finished(QNetworkReply *reply){
    if(reply->error()){
        qDebug() << reply->errorString();
        return;
    }
    QString answer = reply->readAll();
    readBuffer = answer.toStdString();
    std::string oi;
    QString qoi;
    oi = get_content_between("<body>\r\n","</body>");
    if(readBuffer.compare(currentOi) == 0){
        return;
    }
    std::cout << oi << std::endl;
    qoi = QString::fromStdString(oi);
    ui->currentMessage->setText(qoi);
    vector<std::string> udps;
    bool check = true;
    if(oi.size()<10){
        check = false;
    }
    while(oi.find(".") > 0 && check){
        int startIndex = oi.find("HC");
        int endIndex;
        try{
            endIndex = oi.find("HC",startIndex + 2) - 5;

        }
        catch(exception){
            endIndex = oi.size();
        }
        if(endIndex < 0){
            endIndex = oi.size();
        }
        string udp = oi.substr(startIndex,endIndex-startIndex);
        int x = oi.find("HC",startIndex + 2);
        if(x < 0){
            check = false;
        }
        else{
            oi = oi.substr(oi.find("HC",startIndex + 2));
        }
        udps.push_back(udp);

    }
    if(udps.size() > 0){
        analytics->goLive(udps);
    }
    QString pairing;
    pairing = QString::fromStdString(to_string(analytics->pairings.size()));
    ui->numberOfPairings->setText(pairing);
    currentOi = readBuffer;
}

std::string MainWindow::get_content_between(std::string str1, std::string str2){
    std::size_t pos1 = readBuffer.find(str1) + str1.size();
    std::size_t pos2 = readBuffer.find(str2) - pos1;
    return readBuffer.substr(pos1, pos2);
};

std::string MainWindow::get_string(){
    return readBuffer;
}
