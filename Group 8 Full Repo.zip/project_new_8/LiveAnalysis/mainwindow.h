#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTimer>
#include <QString>
#include <iostream>
#include "../Starting/compdatetime.h"
#include "../Starting/udptodata.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    std::string get_content_between(std::string str1, std::string str2);
    std::string get_string();
    UDPToData *analytics;
    std::string currentOi;


private:
    Ui::MainWindow *ui;
    QNetworkAccessManager *mng;
    QNetworkRequest request;
    QTimer *timer;
    std::string readBuffer;

private slots:
    void mng_finished(QNetworkReply *reply);
    void get_UDP_from_web();
};


#endif // MAINWINDOW_H
