#include "createscenario.h"
#include "ui_createscenario.h"
#include <QTextStream>
#include <vector>
#include <string>
#include <random>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <sstream>

/// need to find the file created

CreateScenario::CreateScenario(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateScenario)
{
    ui->setupUi(this);
    this->setStyleSheet("\nQPushButton:hover{background-color: #dd9c23}\nQWidget{background-color: #edb85c}QPushButton{background-color: #f4b642;\nborder : 2px solid #000000; border-radius: 6px}QComboBox{border : 2px solid #000000; border-radius: 6px}QTimeEdit{border : 2px solid #000000; border-radius: 6px}QDateEdit{border : 2px solid #000000; border-radius: 6px}");
    ui->comboBox->addItem("sunny");
    ui->comboBox->addItem("cloudy");
    ui->comboBox->addItem("raining");

    ui->timeEdit->setDisplayFormat("HH:mm");
    ui->timeEdit_2->setDisplayFormat("HH:mm");
}

CreateScenario::~CreateScenario()
{
    delete ui;
}

void CreateScenario::on_pushButton_clicked()
{
     std::ofstream file;
     file.open("user.txt");
     srand(time(0));

     QString activity = "";

     std::vector<QTime> times;

     QTime start = ui->timeEdit->time();
     QTime end = ui->timeEdit_2->time();

     std::stringstream ss;

     QDate date = ui->dateEdit->date();
     QString str = "";//QByteArray
     int day = date.day();
     int month = date.month();
     int year = date.year();
     if(day<10)str+="0"+QString::number(day);
     else {str+= QString::number(day);}
     str+=".";
     if(month<10)str+="0"+QString::number(month);
     else {str+= QString::number(month);}
     str+= ".";

     int yr = year%2000;
     if(yr<10)str+="0"+QString::number(yr);
     else {str+= QString::number(yr);}
     QString ttemp = "";

     //calculate diff
     int startS = 3600*start.hour()+60*start.minute();//+start.second();
     int endS = 3600*end.hour()+60*end.minute();//+end.second();
     int diff =  endS - startS;

     if((!start.isValid())||(!end.isValid())){
         ui->label->setText("The times you chose are are invalid");
     }

     if(endS<startS){
         ui->label->setText("start Time is smaller than end Time");
     }

     QTime temp = start;

     QString s = QString::number(diff);
     QString s1 = QString::number(startS);
     QString s2 = QString::number(endS);//temp.toString();
     QString tt = start.toString()+end.toString();

     while (diff>0) {
         times.push_back(temp);
         temp = temp.addSecs(60);
         diff = diff - 60;
         int min = temp.minute();
         int hr = temp.hour();

         QString hrStr = "";
         if(hr<10){ hrStr = "0"+QString::number(hr);}
         else { hrStr = QString::number(hr);}

         QString minStr = "";
         if(min<10){ minStr = "0"+QString::number(min);}//file.write("here");
         else { minStr = QString::number(min);}

         bool swarmAlreadyOcurred = false;
        if(ui->comboBox->currentText()=="sunny"){
             int rannum  = (rand()%4)+1;
             int ranMum  = (rand()%10)+1;
             int n = rannum;
             int m = ranMum;
             std::string nstr = std::to_string(n)+std::to_string(m);
             activity = QString::fromStdString("."+nstr);

             //make 0.5 - swarming rare
             if(swarmAlreadyOcurred==false){
                 int swarm_chance  = (rand()%100)+1;
                 if(swarm_chance>90)activity = QString::fromStdString(".50") ;
                 swarmAlreadyOcurred=true;
             }
        }else if (ui->comboBox->currentText() == "cloudy") {
             int rannum  = (rand()%2)+1;
             int ranMum  = (rand()%10);
             int n = rannum;
             int m = ranMum;
             std::string nstr = std::to_string(n)+std::to_string(m);
             activity = QString::fromStdString("."+nstr);
         }else if(ui->comboBox->currentText() == "raining"){ //raining
             int rannum  = (rand()%1);
             int ranMum  = (rand()%10);
             int n = rannum;
             int m = ranMum;
             std::string nstr = std::to_string(n)+std::to_string(m);
             activity = QString::fromStdString("."+nstr);
         }

         ttemp += ""+str+" "+hrStr+"."+minStr+" "+activity+" \n";
     }

     std::string line = ttemp.toStdString();
     file<<line;
     ui->label->setText(ttemp);

     file.close();
     ui->processLabel->setText("Processing");
     dm = new DataManager();
     dm->setDTU("user.txt");
     dm->generateUDP(dm->scenVector.size() + 1);
     string tempStr = "";
     tempStr += "Scenario ";
     int x = dm->scenVector.size()+1;
     tempStr += to_string(x);
     tempStr += " created";
     ui->processLabel->setText(QString::fromStdString(tempStr));
}

void CreateScenario::on_closeButton_clicked()
{
    this->close();
}
