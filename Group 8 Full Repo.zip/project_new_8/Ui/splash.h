#ifndef SPLASH_H
#define SPLASH_H

#include <QDialog>

namespace Ui {
class Splash;
}

class Splash : public QDialog
{
    Q_OBJECT

public:
    explicit Splash(QWidget *parent = nullptr);
    ~Splash();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Splash *ui;
};

#endif // SPLASH_H
