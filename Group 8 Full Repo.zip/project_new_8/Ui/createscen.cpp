#include "createscen.h"
#include "ui_createscen.h"

CreateScen::CreateScen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CreateScen)
{
    ui->setupUi(this);
}

CreateScen::~CreateScen()
{
    delete ui;
}
