#include "splash.h"
#include "ui_splash.h"

Splash::Splash(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Splash)
{
    this->setStyleSheet("\nQPushButton:hover{background-color: #dd9c23}\nQWidget{background-color: #edb85c}QPushButton{background-color: #f4b642;\nborder : 2px solid #000000; border-radius: 6px}");

    ui->setupUi(this);
}

Splash::~Splash()
{
    delete ui;
}

void Splash::on_pushButton_clicked()
{
    this->close();
}
