#ifndef USERMAIN_H
#define USERMAIN_H

#include <QMainWindow>

namespace Ui {
class UserMain;
}

class UserMain : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserMain(QWidget *parent = nullptr);
    ~UserMain();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::UserMain *ui;
};

#endif // USERMAIN_H
