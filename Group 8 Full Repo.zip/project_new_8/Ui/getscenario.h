#ifndef GETSCENARIO_H
#define GETSCENARIO_H

#include <QDialog>
#include <QMainWindow>
#include "../database/datamanager.h"
#include "../Starting/udptodata.h"
#include "../database/udptable.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <functional>
#include <iostream>
#include <QTimer>
#include <QDebug>

namespace Ui {
class GetScenario;
}

class GetScenario : public QDialog
{
    Q_OBJECT

public:
    explicit GetScenario(QWidget *parent = nullptr);
    ~GetScenario();

    DataManager *datamanager;
    UDPTable *udptable;
    UDPToData *udp_to_data;
    QTimer *timer;
    int timerCount;
    int messageCount;
    long time_track;
    long time_step;
    vector<int> times;
    int desire_speed;
    int swarmTime;


private slots:
    void on_pushButton_clicked();
    void print_stuff();

private:
    Ui::GetScenario *ui;
};

#endif // GETSCENARIO_H
