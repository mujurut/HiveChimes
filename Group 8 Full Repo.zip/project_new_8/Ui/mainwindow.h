#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "../database/datamanager.h"
#include "../Starting/udptodata.h"
#include "../database/udptable.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <functional>
#include <iostream>
#include "createscenario.h"
#include "getscenario.h"
#include "splash.h"
#include <vector>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    public:
        explicit MainWindow(QWidget *parent = nullptr);
        ~MainWindow();

        //DataManager *datamanager;
        //UDPTable *udptable;
        //UDPToData *udp_to_data;
        Ui::MainWindow *ui;
        QTimer* timer;

    private slots:
        void on_pushButton_clicked();

        void on_pushButton_2_clicked();

        void on_pushButton_3_clicked();

    private:

};

#endif // MAINWINDOW_H
