#include "usermain.h"
#include "ui_usermain.h"
//#include "mainwindow.h"

UserMain::UserMain(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UserMain)
{
    ui->setupUi(this);
}

UserMain::~UserMain()
{
    delete ui;
}

void UserMain::on_pushButton_clicked()
{


}

void UserMain::on_pushButton_2_clicked()
{

}
