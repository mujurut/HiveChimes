#ifndef CREATESCENARIO_H
#define CREATESCENARIO_H

#include <QDialog>
#include <string>
#include <iostream>
#include <QTimeEdit>
#include <QTimer>
#include <QDate>
#include "../database/datamanager.h"

namespace Ui {
class CreateScenario;
}

class CreateScenario : public QDialog
{
    Q_OBJECT

public:
    explicit CreateScenario(QWidget *parent = nullptr);
    ~CreateScenario();
    DataManager *dm;

private slots:
    void on_pushButton_clicked();

    void on_closeButton_clicked();

private:
    Ui::CreateScenario *ui;
};

#endif // CREATESCENARIO_H
