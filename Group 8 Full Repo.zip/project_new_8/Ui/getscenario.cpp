#include "getscenario.h"
#include "ui_getscenario.h"

GetScenario::GetScenario(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GetScenario)
{
    ui->setupUi(this);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(print_stuff()));

    this->setStyleSheet("\nQPushButton:hover{background-color: #dd9c23}\nQWidget{background-color: #edb85c}QPushButton{background-color: #f4b642;\nborder: 2px solid #000000; border-radius: 6px}QComboBox{border: 2px solid #000000; border-radius: 6px}QComboBox{border : 2px solid #000000; border-radius: 6px}QComboBox::drop-down{border-bottom-right-radius: 6px;border-top-right-radius: 6px; border-left-color: #000000; border-left-style: solid; subcontrol-origin: padding; subcontrol-position: top right; width: 15px;}QTimeEdit{border : 2px solid #000000; border-radius: 6px}QDateEdit{border : 2px solid #000000; border-radius: 6px}\nQPushButton:hover{background-color: #dd9c23}\nQWidget{background-color: #edb85c}QPushButton{background-color: #f4b642;\nborder : 2px solid #000000; border-radius: 6px}");

    datamanager = new DataManager;
    int x  = datamanager->scenVector.size();

    for (int i = 0; i < x; i++) {
        int tempID = datamanager->scenVector.at(i).id;
        ui->comboBox->addItem(QString::number(tempID));
    }

    ui->lineEdit->setText("1");
}

GetScenario::~GetScenario()
{
    delete ui;
}

void GetScenario::print_stuff()
{

    timerCount += 250 * time_step;
    string out = "";
    while(messageCount < datamanager->currentRun.size() && times.at(messageCount) < timerCount){
        out += datamanager->currentRun.at(messageCount).originalMessage;
        out += "\n";
        messageCount++;
    }
    if(!(messageCount < datamanager->currentRun.size())){
        timer->stop();
    }
    if(datamanager->utd->swarmCheck.happened && timerCount > swarmTime){
        string swarmOut = "Swarm happened at ";
        swarmOut += datamanager->swarmTime.toUdpString().substr(12);
        this->ui->label_5->setText(QString::fromStdString(swarmOut));
    }
    if(out.compare("") != 0){
        this->ui->label->setText(QString::fromStdString(out));
    }

}

void GetScenario::on_pushButton_clicked()
{

     //get the current scenario from combobox
     string selectedScenario = ui->comboBox->currentText().toStdString();
     times.clear();
     this->datamanager->currentRun.clear();
     messageCount = 0;

     //get the speed that the user wants
     QString velocity = ui -> lineEdit -> text();
     desire_speed = std::stoi(velocity.toStdString());

     //get that scenario's ID
     int idScen = stoi(selectedScenario);
     datamanager->selectScenario(idScen);
     datamanager->analysis();

     //print the scenario ID and date on the label/screen
     QString scnId = QString::number(idScen);
     string scnDate = datamanager->scenVector.at(idScen-1).date;
     QString scnDateQstr  = QString::fromStdString(scnDate);
     ui->label_2->setText(scnId +" "+ scnDateQstr);

     //get that scenarios UDP messages

     int time_diff = 0;

     int y =  datamanager->currentRun.size();
     CompDateTime timeI = datamanager->currentRun.at(0).dt;
     times.push_back(0);

     for (int i=0;i<y-1;i++) {
         if(i == 157){
             int jej = 5;
         }

         UDPMessage udpmessage =  datamanager->currentRun.at(i);
         string str = udpmessage.dt.toUdpString();
         QString messageStr = QString::fromStdString(str);
         UDPMessage udpmessage2 =  datamanager->currentRun.at(i+1);
         CompDateTime timeF = udpmessage2.dt;
             time_diff =  timeI.compVal(timeF);

             times.push_back(time_diff);

//             //increase speed
//             QString strTemp = ui->lineEdit->text();
//             speed = strTemp.toInt();
//             time_diff = time_diff*(1/speed);

//             //printing the data in real time
//             auto x = std::chrono::steady_clock::now() + std::chrono::milliseconds(time_diff);//time_diff
//             //std::this_thread::sleep_until(x);//until(x)
             if(datamanager->utd->swarmCheck.happened){
                 swarmTime = timeI.compVal(datamanager->swarmTime);
             }

             //if swarm/special event happens , call it out at that time
             /*int xx = udp_to_data->swarmCheck.times.size();
             if(xx == 0){
                 for (int j=0;j<xx;j++) {
                     CompDateTime comp1 = udpmessage.dt;
                     CompDateTime comp2 = udp_to_data->swarmCheck.times.at(j);
                     int compVal = comp1.compVal(comp2);
                     if(compVal == 0){
                         QString temp = "SWARM ALERT";
                         ui->label->setText(temp);
                        }
                     }
                 }
             }*/


     }
    time_track = 0;
    timerCount = 0;
    time_step = (60/desire_speed);
     timer -> start(250);

}
