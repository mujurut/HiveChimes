#include "selectscenario.h"
#include "ui_selectscenario.h"

SelectScenario::SelectScenario(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SelectScenario)
{
    ui->setupUi(this);

    //datamanager = new DataManager;
    //datamanager->setDTU("./info.txt");
    //datamanager->generateUDP(datamanager->scenVector.size()+1);
    //datamanager->selectScenario(datamanager->scenVector.size()+1);
    //datamanager = new DataManager;
    ui->setupUi(this);

    //int x  = datamanager->scenVector.size();
    //datamanager->scenVector.size()

    //for (int i = 0; i < x; i++) {
        //int tempID = datamanager->scenVector.at(i).id;
         //ui->comboBox->addItem(QString::number(tempID));
   // }

    ui->lineEdit->setText("1");

}

SelectScenario::~SelectScenario()
{
    delete ui;
}

//void SelectScenario::on_pushButton_clicked()
//{
   // ui->label_3->setText("we good");
    /*//get the current scenario from combobox
    string selectedScenario = ui->comboBox->currentText().toStdString();

    //get that scenario's ID
    int idScen = stoi(selectedScenario);
    datamanager->selectScenario(idScen);

    //print the scenario ID and date on the label/screen
    QString scnId = QString::number(idScen);
    string scnDate = datamanager->scenVector.at(idScen).date;
    QString scnDateQstr  = QString::fromStdString(scnDate);
    ui->label_3->setText(scnId + " sfgsfgsfgsfgsfgsfg  "+ scnDateQstr);*/

    //get that scenarios UDP messages
    //int x =datamanager->scenVector.at(idScen).id;

    //int time_diff = 0;
    //bool loop = true;
    //int speed = 1;
    //ui->lineEdit->setText("1");

    //int y =  datamanager->currentRun.size();

    //for (int i=0;i<y;i++) {
        //UDPMessage udpmessage =  datamanager->currentRun.at(i);
        //string str = udpmessage.dt.toUdpString();
        //QString messageStr = QString::fromStdString(str);

        //if(i<y-1){
            //UDPMessage udpmessage2 =  datamanager->currentRun.at(i+1);
            //int timeI = udpmessage.dt.hour*3600+udpmessage.dt.minute*60+udpmessage.dt.ms;
            //int timeF = udpmessage2.dt.hour*3600+udpmessage2.dt.minute*60+udpmessage2.dt.ms;
            //time_diff =  timeF-timeI;


            //imcrease speed
            //QString strTemp = ui->lineEdit->text();
            //speed = strTemp.toInt();
            //time_diff = time_diff*(1/speed);


            //printing the data in real time
            //auto x = std::chrono::steady_clock::now() + std::chrono::milliseconds(time_diff);
            //std::this_thread::sleep_until(x);


            //if swarm/special event happens , call it out at that time
            //int xx = udp_to_data->swarmCheck.times.size();
            //for (int j=0;j<xx;j++) {
                //int comp1 = (udpmessage.dt.hour*3600+udpmessage.dt.minute+udpmessage.dt.ms);
                //int comp2 = (udp_to_data->swarmCheck.times.at(j).hour*3600+udp_to_data->swarmCheck.times.at(j).minute*60+udp_to_data->swarmCheck.times.at(j).ms);
                //if(comp1==comp2){
                    //QString temp = "SWARM ALERT";
                    //ui->label->setText(temp);
                //}
           // }
   // }
    //if(i==y)loop=false;

    //}
    //while (loop){}
//}



void SelectScenario::on_pushButton_clicked()
{
    ui->label->setText("h");
    ui->label_2->setText("sf");
    ui->label_3->setText("dada");
    ui->label_4->setText("zdc");
}

void SelectScenario::on_pushButton_2_clicked()
{
    ui->label->setText("sssfs");
}
