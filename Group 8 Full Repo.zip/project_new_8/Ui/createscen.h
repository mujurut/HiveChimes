#ifndef CREATESCEN_H
#define CREATESCEN_H

#include <QWidget>

namespace Ui {
class CreateScen;
}

class CreateScen : public QWidget
{
    Q_OBJECT

public:
    explicit CreateScen(QWidget *parent = nullptr);
    ~CreateScen();

private:
    Ui::CreateScen *ui;
};

#endif // CREATESCEN_H
