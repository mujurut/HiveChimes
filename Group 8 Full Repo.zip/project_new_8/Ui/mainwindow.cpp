#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("\nQPushButton:hover{background-color: #dd9c23}\nQWidget{background-color: #edb85c}QPushButton{background-color: #f4b642;\nborder : 2px solid #000000; border-radius: 6px}");
    Splash splash;
    splash.setModal(true);
    splash.exec();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{

}

/*
void timer_start(std::function<void()> func, unsigned int interval){
    std::thread([func, interval](){
        while (true){
            auto x = std::chrono::steady_clock::now() + std::chrono::milliseconds(interval);
            func();
            std::this_thread::sleep_until(x);
        }
    }).detach();
}


void do_something(){

    //ui->label->setText(str);
    //std::cout << "Worm moved!" << std::endl;
}
*/


void MainWindow::on_pushButton_2_clicked()
{
    CreateScenario createscenario;
    createscenario.setModal(true);
    createscenario.exec();
}

void MainWindow::on_pushButton_3_clicked()
{
    GetScenario getscenario;
    getscenario.setModal(true);
    getscenario.exec();
}
