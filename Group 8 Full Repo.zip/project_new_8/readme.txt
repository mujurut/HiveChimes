How to Run/Verify the deliverable


Part 3

In this same folder is a file called "info.txt". This needs to be put into the Starting build folder in order for this to work. This part reads that file and gathers three vales: A date, a time, and a level. This level is used in a poisson randomization to generate the number of UDP messages that are created for that specific time. These are put into vectors which are all compiled into full UDP messages. By running the main function, the first part of what is output will show the values that are being pulled out of the file, and the second part is the randomly generated UDP messages based on those values.

Part 4:

By creating a text document in the Starting build folder called udpMessages (or copying over the file in this folder) that contains UDP Messages (they need to follow the exact format in terms of Date and Time), all of them will be added to a vector stored with their date, time, the specific board, and a binary representation of the signal received. Running the main function will print out a time string of the second vector entry. This is not just a substring of what was sent in, but a string representation of the date and time read in and converted to a CompDateTime object. It will also print out the binary representation of that entry (which is 16 if the message in the one we created is used). This part also tests the CompDateTime compare method and will return the comparative value of the first 2 UDP messages that have been parsed (Note: If the first UDP message has multiple board signal values then the compare will be zero as it considers these different objects)